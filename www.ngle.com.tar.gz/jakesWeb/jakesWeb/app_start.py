from flask import Flask, request, redirect, url_for, send_from_directory, render_template

app = Flask(__name__)
app.debug = True

# Routes
@app.route('/', methods=['GET'])
def root():
	return app.send_static_file('index.html')

@app.route('/<path:path>')
def static_prox(path):
	return app.send_static_file(path)

@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('500.html'), 500

@app.errorhandler(403)
def page_forbidden(e):
    return render_template('403.html'), 403

if __name__ == "__main__":
	app.run(host='0.0.0.0', port=80, threaded=True)
