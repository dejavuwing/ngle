<!--AceCounter2 Log Gathering for AceTag Manager V.9.0.20160715-->

var _AceTM=(function(_j,_s,_b,_o,_y){
if(typeof(_y.em)=='undefined'&&_j!=0){var _tgn=[];for(var _aix in _y){if(typeof(_y[_aix])!='function'){_tgn.push(_aix);};}
var _at=(new Date().getTime());var _lh=(_o.indexOf('http')==0?_o:'http:')+'//'+_s+'/'+_b;_y.acid=_j;_y.em=_at;
var _pr='?aci='+_j+'&dn='+escape(location.hostname)+'&ty='+escape(_tgn.join('.'))+'&ct=godo'+'&ti='+_at;
var _wj='<scr'+'ipt'+' type="text/javascr'+'ipt" src="'+_lh+_pr+'"></scr'+'ipt>';document.writeln(_wj);}return _y;
})(100076,'atm.acecounter.com','ac.js',location.protocol,window._AceTM||{});

