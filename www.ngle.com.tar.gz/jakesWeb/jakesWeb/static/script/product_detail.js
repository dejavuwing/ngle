<!-- AceCounter eCommerce (Product_Detail) v7.5 Start -->
<!-- Function and Variables Definition Block Start -->

var _JV="AMZ2013010701";//script Version
var _UD='undefined';
var _UN='unknown';

function _IDV(a){return (typeof a!=_UD)?1:0}
var _CRL='http://'+'gtc14.acecounter.com:8080/';
var _GCD='AS4A40851367773';

if( document.URL.substring(0,8) == 'https://' ){ _CRL = 'https://gtc14.acecounter.com/logecgather/' ;};
if(!_IDV(_A_i)) var _A_i = new Image() ;
if(!_IDV(_A_i0)) var _A_i0 = new Image() ;
if(!_IDV(_A_i1)) var _A_i1 = new Image() ;
if(!_IDV(_A_i2)) var _A_i2 = new Image() ;
if(!_IDV(_A_i3)) var _A_i3 = new Image() ;
if(!_IDV(_A_i4)) var _A_i4 = new Image() ;

function _RP(s,m){if(typeof s=='string'){if(m==1){return s.replace(/[#&^@,]/g,'');}else{return s.replace(/[#&^@]/g,'');} }else{return s;} };
function _RPS(a,b,c){var d=a.indexOf(b),e=b.length>0?c.length:1; while(a&&d>=0){a=a.substring(0,d)+c+a.substring(d+b.length);d=a.indexOf(b,d+e);}return a};
function AEC_F_D(pd,md,cnum){var i=0,amt=0,num=0;var cat='',nm='';num=cnum;md=md.toLowerCase();if(md=='b'||md=='i'||md=='o'){for(i=0;i<_A_pl.length;i++){if(_A_nl[i]==''||_A_nl[i]==0)_A_nl[i]='1';if(num==0||num=='')num='1';if(_A_pl[i]==pd){nm=_RP(_A_pn[i]);amt=(parseInt(_RP(_A_amt[i],1))/parseInt(_RP(_A_nl[i],1)))*num;cat=_RP(_A_ct[i]);var _A_cart=_CRL+'?cuid='+_GCD;_A_cart+='&md='+md+'&ll='+_RPS(escape(cat+'@'+nm+'@'+amt+'@'+num+'^&'),'+','%2B');break;};};if(_A_cart.length>0)_A_i.src=_A_cart+"rn="+String(new Date().getTime());setTimeout("",2000);};};

if(!_IDV(_A_pl)) var _A_pl = Array(1) ;
if(!_IDV(_A_nl)) var _A_nl = Array(1) ;
if(!_IDV(_A_ct)) var _A_ct = Array(1) ;
if(!_IDV(_A_pn)) var _A_pn = Array(1) ;
if(!_IDV(_A_amt)) var _A_amt = Array(1) ;
if(!_IDV(_pd)) var _pd = '' ;
if(!_IDV(_ct)) var _ct = '' ;
if(!_IDV(_amt)) var _amt = '' ;

<!-- Function and Variables Definition Block End-->