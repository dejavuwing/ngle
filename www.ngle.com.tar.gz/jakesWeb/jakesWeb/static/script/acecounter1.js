<!-- AceCounter Log Gathering Script V.7.5.2013010701 -->
var _AceGID=(function(){
	var Inf=['gtc14.acecounter.com','8080','AS4A40851367773','AW','0','NaPm,Ncisy','ALL','0'];
	var _CI=(!_AceGID)?[]:_AceGID.val;
	var _N=0;
	var _T=new Image(0,0);if(_CI.join('.').indexOf(Inf[3])<0){ _T.src =( location.protocol=="https:"?"https://"+Inf[0]:"http://"+Inf[0]+":"+Inf[1]) +'/?cookie'; _CI.push(Inf);  _N=_CI.length; } return {o: _N,val:_CI};
})();
var _AceCounter=(function(){
	var G=_AceGID;if(G.o!=0){
		var _A=G.val[G.o-1];
		var _G=( _A[0]).substr(0,_A[0].indexOf('.'));
		var _C=(_A[7]!='0')?(_A[2]):_A[3];
		var _U=( _A[5]).replace(/\,/g,'_');
		var _S=((['<scr','ipt','type="text/javascr','ipt"></scr','ipt>']).join('')).replace('tt','t src="'+location.protocol+ '//cr.acecounter.com/Web/AceCounter_'+_C+'.js?gc='+_A[2]+'&py='+_A[4]+'&gd='+_G+'&gp='+_A[1]+'&up='+_U+'&rd='+(new Date().getTime())+'" t');document.writeln(_S); return _S;}
	})();
<!-- AceCounter Log Gathering Script End -->