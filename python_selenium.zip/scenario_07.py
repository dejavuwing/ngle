import time
import acecounter as ac

if __name__ == "__main__":
	a = ac.acecounter()

	# 1. search.daum.net (다음 브랜드검색)
	# 2. "버그" 검색
	# 3. 엔글 링크 클릭
	a.startExternalToNgle('search.daum.net', 'ad_search', 'daum_brand_2')

	#4. 엔글 사이트 접속
	# 5. 로그인 (aaa006)
	a.direct_Login_success('aaa006')	# (page:2)!

	# 6. 상품 리스트 보기
	# 7. 상품 정보 보기 (Skin_2)
	# 8. 바로 구매 (1개)
	a.order_productDetail_direct_success('Skin 2')	# (page:3)!

	# 9. 상품 리스트 보기
	# 10. 상품 정보 보기 (Skin_2)
	# 11. 카트에 담기 (3개)
	# 12. 주문 완료
	a.order_success('Skin 2', '3')	# (page:6)!

	# 13. 사이트 이탈 (www.google.com)
	a.moveOut('www.google.com')

	# 14. 접속 종료
	a.closeDriver()
