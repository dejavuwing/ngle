import time
import acecounter as ac

if __name__ == "__main__":
	a = ac.acecounter()

	# 1. blog.naver.com (바이럴 광고)
	# 2. 바이럴 링크 확인 (Viral Blog 1)
	# 3. 엔글 링크 클릭
	a.startExternalToNgle('blog.naver.com', 'ad_viral', 'viral_blog_1')

	# 4. 엔글 사이트 접속
	# 5. 로그인 (aaa006)
	a.direct_Login_success('aaa006')	# (page:2)!

	# 6. 상품 리스트 보기
	# 7. 상품 정보 보기 (Skin_2)
	# 8. 바로 구매 완료 (1개)
	a.order_productDetail_direct_success('Skin 2')	# (page:3)!

	# 9. 상품 리스트 보기
	# 10. 상품 정보 보기 (Skin_2)
	# 11. 카트에 담기 (3개)
	# 12. 주문 완료
	a.order_success('Skin 2', '3')	# (page:6)!

	# 13 내부 검색 ("amazon")
	# 14 내부 검색 ("camera")
	a.search_continue('amazon', 'camera')	# (page:3)!

	# 15. 접속 종료
	a.closeDriver()
