import time
import acecounter as ac

if __name__ == "__main__":
	a = ac.acecounter()

	# 1. mail.daum.net (이메일 광고)
	# 2. 이메일 광고확인 (Email 1)
	# 3. 엔글 링크 클릭
	a.startExternalToNgle('mail.daum.net', 'ad_mail', 'email_1')

	# 4. 엔글 사이트 접속
	# 5. 로그인 (aaa009)
	a.direct_Login_success('aaa009')	# (page:2)!

	# 6. 내부 검색 ("camera")
	a.search_product('camera')	# (page:2)!

	# 7. 회원 탈퇴 (ddd002)
	a.withdraw_seccess('aaa002')	# (page:4)!

	# 8. 접속 종료
	a.closeDriver()
