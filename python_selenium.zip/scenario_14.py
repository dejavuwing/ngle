import time
import acecounter as ac

if __name__ == "__main__":
	a = ac.acecounter()

	# 1. search.naver.com (네이버 배너광고)
	# 2. "삼성 TV 1" 클릭
	# 3. 엔글 링크 클릭
	a.startExternalToNgle('search.naver.com', 'ad_banner', 'naver_banner_2')

	# 4. 엔글 사이트 접속
	# 5. 내부 검색 ("doll")
	a.search_product('doll')	# (page:2)!

	# 6. 404 에러
	# 7. 뒤로가기
	a.error404()
	
	# 8. 접속 종료
	a.closeDriver()
