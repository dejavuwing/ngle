import time
import acecounter as ac

if __name__ == "__main__":
	a = ac.acecounter()

	# 1. shopping.daum.net (자연유입)
	# 2. "엔글" 검색 
	# 3. 엔글 링크 클릭
	a.startExternalToNgle('shopping.daum.net', 'free_search', 'go_ngle')

	# 4. 엔글 사이트 접속
	# 5. 로그인 (aaa010)
	a.direct_Login_success('aaa010')	# (page:2)!

	# 6. 상품 리스트 보기
	# 7. 상품 정보 보기 (Skin_3)
	# 8. SNS 공유 (twitter)
	# 9. 리뷰쓰기 (Star 5)
	# 10. 상품 정보 보기 (Skin_3)
	a.shareSNS_writeReview('Skin 3', 'twitter', 'star_5')	# (page:4)!

	# 11. 새로고침
	a.reFresh()

	# 12. 내부 검색 ("family")
	a.search_product('family')	# (page:2)!

	# 13. 접속 종료
	a.closeDriver()
