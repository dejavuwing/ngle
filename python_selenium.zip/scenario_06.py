import time
import acecounter as ac

if __name__ == "__main__":
	a = ac.acecounter()

	# 1. search.daum.net (다음 클릭스)
	# 2. "판교" 검색
	# 3. 엔글 링크 클릭
	a.startExternalToNgle('search.daum.net', 'ad_search', 'daum_clicks_2')

	# 4. 엔글 사이트 접속
	# 5. 회원가입 (ccc002)
	a.joinUser_success('ccc002')	# (page:5)!

	# 6. 내부 검색 ("dress")
	# 7. 상품 정보 보기 (Dress_1)
	# 8. 바로 구매	(1개)
	a.search_direct_order_success('dress', 'Dress 1')	# (page:4)!

	# 9. 파일 다운로드 (*.zip)
	a.download_file_zip()	# (page:1)!

	# 10. 접속 종료
	a.closeDriver()
