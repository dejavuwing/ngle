import time
import acecounter as ac

if __name__ == "__main__":
	a = ac.acecounter()

	# 1. search.naver.com (자연유입)
	# 2. "엔글" 검색
	# 3. 엔글 링크 클릭
	a.startExternalToNgle('search.naver.com', 'free_search', 'go_ngle')

	# 4. 엔글 사이트 접속
	# 5. 접속 종료
	a.closeDriver()
