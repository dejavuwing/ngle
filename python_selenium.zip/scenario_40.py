import time
import acecounter as ac

if __name__ == "__main__":
	a = ac.acecounter()

	# 1. mail.daum.net (자연유입)
	# 2. "엔글" 검색 
	# 3. 엔글 링크 클릭
	a.startExternalToNgle('mail.daum.net', 'free_search', 'go_ngle')

	# 4. 엔글 사이트 접속
	# 5. 내부 배너 클릭 (main_banner_1)
	a.click_main_banner('main_banner_1')	# (page:1)!

	# 6. 상품 정보 보기 (samsum_tv_3)
	# 7. 바로 구매 완료 (1개)
	a.order_productDetail_direct_success('Samsum TV 3')	# (page:3)!

	# 8. 파일 다운로드 (*.zip)
	a.download_file_zip()	# (page:1)!

	# 9. 접속 종료
	a.closeDriver()
