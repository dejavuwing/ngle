import time
import acecounter as ac

if __name__ == "__main__":
	a = ac.acecounter()

	# 1. www.google.com (구글 애드워즈)
	# 2. "게임큐에이" 검색
	# 3. 엔글 링크 클릭
	a.startExternalToNgle('www.google.com', 'ad_search', 'google_ad_2')

	# 4. 엔글 사이트 접속
	# 5. 로그인 (aaa008)
	a.direct_Login_success('aaa008')	# (page:2)!

	# 6. 상품 리스트 보기
	# 7. 상품 정보 보기 (LG_TV_1)
	# 8. SNS 공유 (facebook)
	# 9. 리뷰쓰기 (Star 4)
	# 10. 상품 정보 보기 (LG_TV_1)
	a.shareSNS_writeReview('LG TV 1', 'facebook', 'star_4')	# (page:4)!

	# 11. 내부 검색 (game)
	# 12. 상품 정보 보기 (Skin 1)
	# 13. 여러상품 구매 (Skin 1 3개, Lotion_4 1개)
	a.search_direct_package_order_success('game', 'Skin 1')

	# 14. 접속 종료
	a.closeDriver()
