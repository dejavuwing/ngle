import time
import acecounter as ac

if __name__ == "__main__":
	a = ac.acecounter()

	# 1. search.naver.com (네이버 배너광고)
	# 2. "LG TV 1" 클릭
	# 3. 엔글 링크 클릭
	a.startExternalToNgle('search.naver.com', 'ad_banner', 'naver_banner_3')

	# 4. 엔글 사이트 접속
	# 5. 상품 정보 보기 (lg_tv_3)
	# 6. Wish 리스트 추가
	a.productDetail_addwishList('LG TV 3')	# (page:3)!

	# 7. 내부 베너 보기
	# 8. 내부 배너 클릭 (sub_banner_3)
	# 9. 바로 구매 완료 (1개)
	a.click_banner_order_success('sub_banner_3', '1')	# (page:6)!

	# 10. 상품 정보 보기 (lg_tv_3)
	# 11. SNS 공유 (pinterest)
	a.click_about_banner_sns('sub_banner_3', 'pinterest')	# (page:2)!

	# 12. 접속 종료
	a.closeDriver()
