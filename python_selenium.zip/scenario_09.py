import time
import acecounter as ac

if __name__ == "__main__":
	a = ac.acecounter()

	# 1. search.daum.net (다음 브랜드검색)
	# 2. "카카오" 검색
	# 3. 엔글 링크 클릭
	a.startExternalToNgle('search.daum.net', 'ad_search', 'daum_brand_3')

	# 4. 엔글 사이트 접속
	# 5. 회원가입 (ccc003)
	a.joinUser_success('ccc003')	# (page:5)!

	# 6. 내부 검색 ("dress")
	# 7. 상품 정보 보기 (Dress_3)
	# 8. Wish 리스트 추가
	# 9. 주문 하기
	# 10. 주문 완료
	a.search_addwith_order_success('dress', 'Dress 3')	# (page:7)!

	# 11. 접속 종료
	a.closeDriver()
