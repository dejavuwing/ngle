import time
from selenium import webdriver


# go to the test site
class acecounter():

	# Create a new instance of the WebDriver
	#driver = webdriver.Firefox()
	driver = webdriver.Chrome("C:/Users/jake/AppData/Local/Programs/Python/chromedriver.exe")
	#driver = webdriver.Ie("C:/Users/jake/AppData/Local/Programs/Python/IEDriverServer.exe")
	#driver = webdriver.Opera()
	sleepTime = 5

	def startExternalToNgle(self, site, menu, keyword):
		# 외부 도메인으로 검색 조건에 맞게 ngle.com으로 접속한다.
		'''
		search.naver.com (ad_search): 유료 마케팅
		naver_click_1 (엔글), naver_click_2 (큐에이), naver_click_3 (게임큐에이), naver_click_4 (QA), naver_click_5 (플랫폼), naver_click_6 (점심식사), naver_brand_1 (엔글)

		search.daum.net (ad_search): 유료 마케팅
		daum_clicks_1 (엔글), daum_clicks_2 (판교), daum_clicks_3 (큐에이), daum_brand_1 (큐에이), daum_brand_2 (버그), daum_brand_3 (카카오), daum_brand_4 (선풍기)

		www.google.com (ad_search): 유료 마케팅
		google_ad_1 (소금쟁이), google_ad_2 (게임큐에이), google_ad_3 (플랫폼쿠에이), google_ad_4 (엔글), google_ad_5 (카카오), google_ad_6 (엔진)

		search.daum.net (ad_search): 유료 마케팅
		nate_go_1 (엔글), nate_go_2 (큐에이), nate_go_3 (기획분석), nate_go_4 (TC), nate_go_5 (버그)

		search.naver.com (ad_banner): 배너 광고
		naver_banner_1 (메인 광고 이미지), naver_banner_2 (삼성 TV 1), naver_banner_3 (LG TV 1), naver_banner_4 (로션 3), naver_banner_5 (드레스 2)

		search.daum.net (ad_banner): 배너 광고
		daum_banner_1 (여름 기획전), daum_banner_2 (가을 기획전), daum_banner_3 (바지 1), daum_banner_4 (삼성 TV 2), daum_banner_5 (LG TV 2)

		search.naver.com (free_search): 자연 유입 (go_ngle)
		search.daum.net (free_search): 자연 유입 (go_ngle)
		www.google.com (free_search): 자연 유입 (go_ngle)

		mail.daum.net (ad_mail): 메일 광고
		email_1, email_2

		blog.naver.com (ad_viral): 바이럴 광고
		viral_blog_1, viral_blog_2, viral_cafe_1, viral_cafe_2, viral_jisicin, viral_auction, viral_yes24



		'''
		driver = self.driver
		domain = "http://" + site

		driver.get(domain)
		time.sleep(self.sleepTime)

		if len(menu) > 0:
			link_search = driver.find_element_by_id(menu)
			link_search.click()
			time.sleep(self.sleepTime)

		if len(keyword) > 0:
			link_search = driver.find_element_by_id(keyword)
			link_search.click()
			time.sleep(self.sleepTime)


	def connect_direct_ngle(self):
		# chrome 으로 www.ngle.com에 바로 접속한다. (자연 유입)
		driver = self.driver

		driver.get("http://www.ngle.com")
		time.sleep(self.sleepTime)

	def moveOut(self, siteUrl):
		# 다른 사이트로 이동한다 (사이트 이탈)
		driver = self.driver
		domain = "http://" + siteUrl

		driver.get(domain)
		time.sleep(self.sleepTime)

	def moveToSinglePage(self, menu):
		# 메뉴를 통해 페이지 이동 (page:1)!
		driver = self.driver

		link_ngle = driver.find_element_by_link_text(menu)
		link_ngle.click()
		time.sleep(self.sleepTime)


	def direct_Login_success(self, loginUser):
		# 바로 로그인 성공 (page:2)!
		driver = self.driver

		link_ngle = driver.find_element_by_link_text("Login")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text(loginUser)
		link_ngle.click()
		time.sleep(self.sleepTime)

	def joinUser_success(self, joinUser):
		# 회원 가입 성공 (page:5)!
		driver = self.driver

		link_ngle = driver.find_element_by_link_text("Login")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text("Join")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text("Next (go to Step2)")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text("Next (go to Step3)")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text(joinUser)
		link_ngle.click()
		time.sleep(self.sleepTime)

	def cancle_joinUser_step2(self):
		# 회원가입 두번째 step에서 cancle  (page:4)
		driver = self.driver

		link_ngle = driver.find_element_by_link_text("Login")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text("Join")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text("Next (go to Step2)")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text("Cancle (go Home)")
		link_ngle.click()
		time.sleep(self.sleepTime)

	def withdraw_seccess(self, withdrawUser):
		# 회원탈퇴 성공 (page:4)!
		driver = self.driver

		link_ngle = driver.find_element_by_link_text("Login")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text("withdraw")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text("Next (go to Step2)")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text(withdrawUser)
		link_ngle.click()
		time.sleep(self.sleepTime)

	def order_success(self, product, cart):
		# 상품정보 확인 후 카트에 넣고 구매 성공 (page:6)!
		driver = self.driver

		link_ngle = driver.find_element_by_link_text("Home")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text(product)
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text(cart)
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text("Order")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text("Next (go to Step2)")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text("Next (go to Finish)")
		link_ngle.click()
		time.sleep(self.sleepTime)

	def cancle_order_step2(self, product, cart):
		# 상품정보 확인 후 카트에 넣고 구매 잰행 중 step 2에서 주문 취소 (page:6)!
		driver = self.driver

		link_ngle = driver.find_element_by_link_text("Home")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text(product)
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text(cart)
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text("Order")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text("Next (go to Step2)")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text("Cancle (go Home)")
		link_ngle.click()
		time.sleep(self.sleepTime)

	def all_clean_cart(self, product, cart):
		# 상품정보 확인 후 카트에 넣고 바로 카트 비우기 (page:4)!
		driver = self.driver

		link_ngle = driver.find_element_by_link_text("Home")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text(product)
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text(cart)
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text("All Clear Cart (go Home)")
		link_ngle.click()
		time.sleep(self.sleepTime)

	def modify_cart_quantity_order_success(self, product, cart):
		# 상품정보 확인 후 카트에 넣고 카트의 상품 갯수 5개로 수정 후 구매 성공 (page:7)!
		driver = self.driver

		link_ngle = driver.find_element_by_link_text("Home")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text(product)
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text(cart)
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text("Modify quantity 5")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text("Order")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text("Next (go to Step2)")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text("Next (go to Finish)")
		link_ngle.click()
		time.sleep(self.sleepTime)

	def order_productList_direct_success(self, order_id):
		# 상품 리스트에서 바로 구매 성공 (page: 2)
		driver = self.driver

		link_ngle = driver.find_element_by_link_text("Home")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_id(order_id)
		link_ngle.click()
		time.sleep(self.sleepTime)

	def order_productDetail_direct_success(self, product):
		# 상품정보 확인 후 바로 구매 성공 (page:3)!
		driver = self.driver

		link_ngle = driver.find_element_by_link_text("Home")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text(product)
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_id('order')
		link_ngle.click()
		time.sleep(self.sleepTime)

	def shareSNS_writeReview(self, product, sns, star):
		# 상품정보 확인 후 SNS 공유 및 리뷰 작성하고 다시 상품정보 확인 (page:4)!
		driver = self.driver

		link_ngle = driver.find_element_by_link_text("Home")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text(product)
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_id(sns)	# it doen't move to page.
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_id('gotoWriteReview')
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_id(star)	# it doen't move to page.
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_id('gotodetail')
		link_ngle.click()
		time.sleep(self.sleepTime)

	def productDetail_addwishList(self, product):
		# 상품정보 확인 후 wish 리스트 추가 (page:3)!
		driver = self.driver

		link_ngle = driver.find_element_by_link_text("Home")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text(product)
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_id('addwith')
		link_ngle.click()
		time.sleep(self.sleepTime)

	def search_product(self, search):
		# 검색 페이지에서 상품 검색만 한다. (page:2)!
		driver = self.driver

		link_ngle = driver.find_element_by_link_text("Search")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text(search)
		link_ngle.click()
		time.sleep(self.sleepTime)

	def search_continue(self, search1, search2):
		# 검색을 연속으로 두 번 한다. (page:3)!
		driver = self.driver

		link_ngle = driver.find_element_by_link_text("Search")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text(search1)
		link_ngle.click()
		time.sleep(self.sleepTime)

		driver.back()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text(search2)
		link_ngle.click()
		time.sleep(self.sleepTime)

	def search_direct_order_success(self, search, product):
		# 검색 후 상품정보 확인 후 바로 구매 성공 (page:4)!
		driver = self.driver

		link_ngle = driver.find_element_by_link_text("Search")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text(search)
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text(product)
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_id('order')
		link_ngle.click()
		time.sleep(self.sleepTime)

	def search_direct_package_order_success(self, search, product):
		# 검색 후 상품정보 확인 후 바로 구매 성공 (page:4)!
		driver = self.driver

		link_ngle = driver.find_element_by_link_text("Search")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text(search)
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text(product)
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_id('package_order')
		link_ngle.click()
		time.sleep(self.sleepTime)

	def search_addwith_order_success(self, search, product):
		# 검색 후 상품정보 확인 후 카트에 넣고 구매 성공 (page:7)!
		driver = self.driver

		link_ngle = driver.find_element_by_link_text("Search")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text(search)
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text(product)
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_id('addwith')
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text("Order")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text("Next (go to Step2)")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text("Next (go to Finish)")
		link_ngle.click()
		time.sleep(self.sleepTime)

	def search_order_success(self, search, product, cart):
		# 검색 후 상품정보 확인 후 카트에 넣고 구매 성공 (page: 7)
		driver = self.driver

		link_ngle = driver.find_element_by_link_text("Search")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text(search)
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text(product)
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text(cart)
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text("Order")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text("Next (go to Step2)")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text("Next (go to Finish)")
		link_ngle.click()
		time.sleep(self.sleepTime)

	def click_marketing(self, marketing_id):
		# 이메일, 바이럴 마케팅 링크 클릭 (page: 2)
		driver = self.driver

		link_ngle = driver.find_element_by_link_text("About")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_id(marketing_id)
		link_ngle.click()
		time.sleep(self.sleepTime)

	def click_main_banner(self, banner_id):
		# 인입 직후 바로 이미지 배너 광고를 클릭한다. (page:1)!
		driver = self.driver

		link_ngle = driver.find_element_by_id(banner_id)
		link_ngle.click()
		time.sleep(self.sleepTime)

	def click_main_banner_addwishlist(self, banner_id):
		# 인입 직후 바로 이미지 배너 광고를 클릭하고 해당 상품을 wish 리스트에 넣는다. (page: 2)
		driver = self.driver

		link_ngle = driver.find_element_by_id(banner_id)
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_id('addwith')
		link_ngle.click()
		time.sleep(self.sleepTime)


	def click_about_banner(self, banner_id):
		# 이미지 배너 광고를 클릭한다. (page: 2)
		driver = self.driver

		link_ngle = driver.find_element_by_link_text("About")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_id(banner_id)
		link_ngle.click()
		time.sleep(self.sleepTime)

	def click_about_banner_sns(self, banner_id, sns):
		# 이미지 배너 광고를 클릭한다. (page:2)!
		driver = self.driver

		link_ngle = driver.find_element_by_link_text("About")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_id(banner_id)
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_id(sns)	# It doesn't move to page.
		link_ngle.click()
		time.sleep(self.sleepTime)

	def click_banner_order_success(self, banner_id, cart):
		# 이미지 배너 광고를 클릭 후 상품을 구입한다. (page:6)!
		driver = self.driver

		link_ngle = driver.find_element_by_link_text("About")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_id(banner_id)
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text(cart)
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text("Order")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text("Next (go to Step2)")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_link_text("Next (go to Finish)")
		link_ngle.click()
		time.sleep(self.sleepTime)

	def click_outlink(self, outlink_id):
		driver = self.driver

		link_ngle = driver.find_element_by_link_text("About")
		link_ngle.click()
		time.sleep(self.sleepTime)

		outlink = driver.find_element_by_id(outlink_id)
		outlink.click()
		time.sleep(self.sleepTime)


	def download_file_zip(self):
		# zip 파일을 다운로드 한다. (page:1)!
		driver = self.driver

		link_ngle = driver.find_element_by_link_text("About")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_id("ngle_zip")
		link_ngle.click()
		time.sleep(self.sleepTime)

	def error404(self):
		# 에러 발생 후 뒤로가기로 나온다. (page: 3)
		driver = self.driver

		link_ngle = driver.find_element_by_link_text("Home")
		link_ngle.click()
		time.sleep(self.sleepTime)

		link_ngle = driver.find_element_by_id("error_404")
		link_ngle.click()
		time.sleep(self.sleepTime)

		driver.back()
		time.sleep(self.sleepTime)

	def goToBack(self):
		# 브라우저에서 이전 페이지로 가기 (page: 1)
		driver = self.driver

		driver.back()
		time.sleep(self.sleepTime)

	def reFresh(self):
		# 브라우저에서 이전 페이지로 가기 (page: 1)
		driver = self.driver

		driver.refresh()
		time.sleep(self.sleepTime)

	def closeDriver(self):
		# 브라우저를 닫는다.
		driver = self.driver

		time.sleep(10)
		driver.quit()

