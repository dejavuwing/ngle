import time
import acecounter as ac

if __name__ == "__main__":
	a = ac.acecounter()

	# 1. search.naver.com (네이버 배너광고)
	# 2. "드레스 2" 클릭
	# 3. 엔글 링크 클릭
	a.startExternalToNgle('search.naver.com', 'ad_banner', 'naver_banner_5')

	# 4. 엔글 사이트 접속
	# 5. 로그인 (aaa011)
	a.direct_Login_success('aaa011')	# (page:2)!

	# 6. 상품 정보 보기 (pant_1)
	# 7. 바로 구매 완료 (1개)
	a.order_productDetail_direct_success('Pant 1')	# (page:3)!

	# 8. 20분 대기 (세션 종료)
	time.sleep(1200)

	# 9. 로그인 (aaa011)
	a.direct_Login_success('aaa011')	# (page:2)!

	# 10. 상품 리스트 보기
	# 11. 상품 정보 보기 (pant_2)
	# 12. 바로 구매 완료 (1개)
	a.order_productDetail_direct_success('Pant 2')	# (page:3)!

	# 13. 20분 대기 (세션 종료)
	time.sleep(1200)

	# 14. 로그인 (aaa011)
	a.direct_Login_success('aaa011')	# (page:2)!

	# 15. 상품 리스트 보기
	# 16. 상품 정보 보기 (pant_3)
	# 17. 바로 구매 완료 (1개)
	a.order_productDetail_direct_success('Pant 3')	# (page:3)!

	# 18. 접속 종료
	a.closeDriver()
