import time
import acecounter as ac

if __name__ == "__main__":
	a = ac.acecounter()

	# 1. www.tistory.com (자연유입)
	# 2. "엔글" 검색 
	# 3. 엔글 링크 클릭
	a.startExternalToNgle('www.tistory.com', 'free_search', 'go_ngle')

	# 4. 엔글 사이트 접속
	# 5. 회원가입 (ccc005)
	a.joinUser_success('ccc005')	# (page:5)!

	# 6. 내부 검색 ("dress")
	# 7. 상품 정보 보기 (Dress_1)
	# 8. 바로 구매 완료 (1개)
	a.search_direct_order_success('dress', 'Dress 1')	# (page:4)!

	#9. 접속 종료
	a.closeDriver()
