import time
import acecounter as ac

if __name__ == "__main__":
	a = ac.acecounter()

	# 1. www.google.com (자연유입)
	# 2. "엔글" 검색
	# 3. 엔글 링크 클릭
	a.startExternalToNgle('www.google.com', 'free_search', 'go_ngle')

	# 4. 엔글 사이트 접속
	# 5. 상품 리스트 보기
	a.moveToSinglePage('Home')	# (page:1)!

	# 6. 내부 검색 ("game")
	a.search_product('game')	# (page:2)!

	# 7. 20분 대기 (세션 종료)
	time.sleep(1200)

	# 8. 상품 상세 보기 (Lotion 3)
	# 9. 카트에 담기 (3개)
	# 10. 주문 완료
	a.order_success('Lotion 3', '3')	# (page:6)!


	# 11. 접속 종료
	a.closeDriver()
