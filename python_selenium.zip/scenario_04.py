import time
import acecounter as ac

if __name__ == "__main__":
	a = ac.acecounter()

	# 1. search.naver.com (네이버 브랜드검색)
	# 2. 브랜드검색
	# 3. 엔글 링크 클릭
	a.startExternalToNgle('search.naver.com', 'ad_search', 'naver_brand_1')

	# 4. 엔글 사이트 접속
	# 5. 접속 종료
	a.closeDriver()
