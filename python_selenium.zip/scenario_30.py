import time
import acecounter as ac

if __name__ == "__main__":
	a = ac.acecounter()

	# 1. mail.gmail.com (이메일 광고)
	# 2. 이메일 광고확인 (Email 2)
	# 3. 엔글 링크 클릭
	a.startExternalToNgle('mail.gmail.com', 'ad_mail', 'email_2')

	# 4. 엔글 사이트 접속
	# 5. 내부 검색 ("doll")
	a.search_product('doll')	# (page:2)!

	# 6. 404 에러
	# 7. 뒤로가기
	a.error404()

	# 8. 접속 종료
	a.closeDriver()
