import time
import acecounter as ac

if __name__ == "__main__":
	a = ac.acecounter()

	# 1. cafe.daum.net (자연유입)
	# 2. "엔글" 검색 
	# 3. 엔글 링크 클릭
	a.startExternalToNgle('cafe.daum.net', 'free_search', 'go_ngle')

	# 4. 엔글 사이트 접속
	# 5. 로그인 (aaa005)
	a.direct_Login_success('aaa005')	# (page:2)!

	# 6. 상품 리스트 보기
	# 7. 상품 정보 보기 (Pant_1)
	# 8. 카트에 담기 (3개)
	# 9. 카트 상품 비우기
	a.all_clean_cart('Pant 1', '3')	# (page:4)!

	# 10. 접속 종료
	a.closeDriver()
