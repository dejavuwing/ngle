import time
import acecounter as ac
from selenium import webdriver

if __name__ == "__main__":
	a = ac.acecounter()

	# 1. story.kakao.com (자연유입)
	# 2. "엔글" 검색 
	# 3. 엔글 링크 클릭
	a.startExternalToNgle('story.kakao.com', 'free_search', 'go_ngle')

	# 4. 엔글 사이트 접속
	# 5. 로그인 (aaa003)
	a.direct_Login_success('aaa003')	# (page:2)!

	# 6. 상품 리스트 보기
	# 7. 상품 정보 보기 (Skin_1)
	# 8. 바로 구매 (1개)
	a.order_productDetail_direct_success('Skin 1')	# (page:3)!

	# 9. 접속 종료
	a.closeDriver()
