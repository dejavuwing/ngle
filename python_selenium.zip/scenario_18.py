import time
import acecounter as ac

if __name__ == "__main__":
	a = ac.acecounter()

	# 1. search.daum.net (다음 배너광고)
	# 2. "가을 기획전" 클릭
	# 3. 엔글 링크 클릭
	a.startExternalToNgle('search.daum.net', 'ad_banner', 'daum_banner_2')

	# 4. 엔글 사이트 접속
	# 5. 로그인 (aaa004)
	a.direct_Login_success('aaa004')	# (page:2)!

	# 6. 상품 리스트 보기
	# 7. 상품 정보 보기 (Dress_2)
	# 8. 카트에 담기 (2개)
	# 9. 카트 상품 수 변경 (5개)
	# 10. 주문 완료
	a.modify_cart_quantity_order_success('Dress 2', '2')	# (page:7)!

	# 11. 접속 종료
	a.closeDriver()
