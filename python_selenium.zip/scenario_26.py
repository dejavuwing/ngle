import time
import acecounter as ac

if __name__ == "__main__":
	a = ac.acecounter()

	# 1. café.naver.com (바이럴 광고)
	# 2. 바이럴 링크 확인 (Viral Cafe 1)
	# 3. 엔글 링크 클릭
	a.startExternalToNgle('cafe.naver.com', 'ad_viral', 'viral_cafe_1')

	# 4. 엔글 사이트 접속
	# 5. 로그인 (aaa007)
	a.direct_Login_success('aaa007')	# (page:2)!

	# 6. 상품 리스트 보기
	# 7. 상품 정보 보기 (Pant_2)
	# 8. 카트에 담기 (2개)
	# 9. 주문 취소 (Step 2)
	a.cancle_order_step2('Pant 2', '2')	# (page:6)!

	# 11. 접속 종료
	a.closeDriver()
