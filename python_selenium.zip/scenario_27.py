import time
import acecounter as ac

if __name__ == "__main__":
	a = ac.acecounter()

	# 1. café.daum.net (바이럴 광고)
	# 2. 바이럴 링크 확인 (Viral Café 2)
	# 3. 엔글 링크 클릭
	a.startExternalToNgle('cafe.daum.net', 'ad_viral', 'viral_cafe_2')

	# 4. 엔글 사이트 접속
	# 5. 로그인 (aaa008)
	a.direct_Login_success('aaa008')	# (page:2)!

	# 6. 상품 리스트 보기
	# 7. 상품 정보 보기 (LG_TV_1)
	# 8. SNS 공유 (facebook)
	# 9. 리뷰쓰기 (Star 4)
	# 10. 상품 정보 보기 (LG_TV_1)
	a.shareSNS_writeReview('LG TV 1', 'facebook', 'star_4')	# (page:4)!

	# 11. 접속 종료
	a.closeDriver()
