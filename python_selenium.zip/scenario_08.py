import time
import acecounter as ac

if __name__ == "__main__":
	a = ac.acecounter()

	# 1. search.daum.net (다음 브랜드검색)
	# 2. "큐에이" 검색
	# 3. 엔글 링크 클릭
	a.startExternalToNgle('search.daum.net', 'ad_search', 'daum_brand_1')

	# 4. 엔글 사이트 접속
	# 5. 내부 배너 클릭 (main_banner_1)
	a.click_main_banner('main_banner_1')	# (page:1)!

	# 6. 상품 정보 보기 (samsum_tv_3)
	# 7. 바로 구매 완료
	a.order_productDetail_direct_success('Samsum TV 3')	# (page:3)!

	# 8. 접속 종료
	a.closeDriver()
