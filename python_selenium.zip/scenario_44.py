import time
import acecounter as ac

if __name__ == "__main__":
	a = ac.acecounter()

	# 1. shopping.naver.com (자연유입)
	# 2. "엔글" 검색 
	# 3. 엔글 링크 클릭
	a.startExternalToNgle('shopping.naver.com', 'free_search', 'go_ngle')

	# 4. 엔글 사이트 접속
	# 5. 로그인 (aaa009)
	a.direct_Login_success('aaa009')	# (page:2)!

	# 6. 내부 검색 ("camera")
	a.search_product('camera')	# (page:2)!

	# 7. 회원 탈퇴 (ddd002)
	a.withdraw_seccess('aaa002')	# (page:4)!

	# 8. 접속 종료
	a.closeDriver()
