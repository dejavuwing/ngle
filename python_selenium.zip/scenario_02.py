import time
import acecounter as ac

if __name__ == "__main__":
	a = ac.acecounter()

	# 1. search.naver.com (네이버 클릭초이스)
	# 2. "큐에이" 검색
	# 3. 엔글 링크 클릭
	a.startExternalToNgle('search.naver.com', 'ad_search', 'naver_click_2')

	# 4. 엔글 사이트 접속
	# 5. 로그인 (aaa004)
	a.direct_Login_success('aaa004')	# (page:2)!

	# 6. 상품 리스트 보기
	# 7. 상품 정보 보기 (Dress_2)
	# 8. 카트에 담기 (2개)
	# 9. 카트 상품 수 변경 (5개)
	# 10. 주문 완료
	a.modify_cart_quantity_order_success('Dress 2', '2')	# (page:7)!
	
	# 11. 접속 종료
	a.closeDriver()
